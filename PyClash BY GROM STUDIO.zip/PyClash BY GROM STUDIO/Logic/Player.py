# -*- coding: utf-8 -*-


class Player:

    HighID = 0
    LowID = 0
    Token = None

    def __init__(self, device):
        self.device = device

    def encode(self):
        return None

# -*- coding: utf-8 -*-
from Packets.Messages.Client import *
from Packets.Messages.Server.Club.AskForAllianceData import AskForAllianceData

availablePackets = {

    10101: Login,
    10108: KeepAlive,
    14302: AskForAllianceData
}

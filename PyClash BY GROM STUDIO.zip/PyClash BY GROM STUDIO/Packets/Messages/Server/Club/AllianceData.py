import time

from Utils.Writer import Writer


class AllianceData(Writer):
    def __init__(self, device, player):
        super().__init__(device)
        self.device = device
        self.player = player
        self.id = 24301
        self.version = 1

    def encode(self):  
        print("[DEBUG] Message AllianceData has been sent.")
